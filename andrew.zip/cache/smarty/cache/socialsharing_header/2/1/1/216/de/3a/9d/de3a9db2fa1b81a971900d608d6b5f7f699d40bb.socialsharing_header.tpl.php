<?php /*%%SmartyHeaderCode:19509128085421bbd76b62e5-06467646%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'de3a9db2fa1b81a971900d608d6b5f7f699d40bb' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/socialsharing/views/templates/hook/socialsharing_header.tpl',
      1 => 1406806960,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19509128085421bbd76b62e5-06467646',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b9f69f3f5_97428833',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b9f69f3f5_97428833')) {function content_54233b9f69f3f5_97428833($_smarty_tpl) {?><meta property="og:title" content="" />
<meta property="og:type" content="product" />
<meta property="og:site_name" content="" />
<meta property="og:description" content="" />
<meta property="og:email" content="" />
<meta property="og:phone_number" content="" />
<meta property="og:street-address" content="" />
<meta property="og:locality" content="" />
<meta property="og:country-name" content="" />
<meta property="og:postal-code" content="" />
<meta property="og:image" content="http://andrew.local/img/p/5/5-large_default.jpg" />
<?php }} ?>
