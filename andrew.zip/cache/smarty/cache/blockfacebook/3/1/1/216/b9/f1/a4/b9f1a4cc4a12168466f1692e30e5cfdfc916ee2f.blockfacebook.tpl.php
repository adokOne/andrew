<?php /*%%SmartyHeaderCode:728737319541c0620ac00c7-12112590%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9f1a4cc4a12168466f1692e30e5cfdfc916ee2f' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/blockfacebook/blockfacebook.tpl',
      1 => 1406806906,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '728737319541c0620ac00c7-12112590',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bdd6ec7ed5_24350325',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bdd6ec7ed5_24350325')) {function content_5421bdd6ec7ed5_24350325($_smarty_tpl) {?><div id="fb-root"></div>
<div id="facebook_block" class="col-xs-4">
	<h4 >Следите за нами в Facebook</h4>
	<div class="facebook-fanbox">
		<div class="fb-like-box" data-href="https://www.facebook.com/prestashop" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false">
		</div>
	</div>
</div>
<?php }} ?>
