<?php /*%%SmartyHeaderCode:10171672735421b3a2278f74-74590985%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b16fee9619a29faa86d4d55e617f28924b00e6a' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blocksocial/blocksocial.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10171672735421b3a2278f74-74590985',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bb658c48c0_69844862',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bb658c48c0_69844862')) {function content_5421bb658c48c0_69844862($_smarty_tpl) {?>
<section id="social_block">
	<ul>
					<li class="facebook">
				<a target="_blank" href="http://www.facebook.com/prestashop">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a target="_blank" href="http://www.twitter.com/prestashop">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a target="_blank" href="http://www.prestashop.com/blog/en/">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a href="https://www.google.com/+prestashop">
        			<span>Google+</span>
        		</a>
        	</li>
                	</ul>
    <h4>Подпишитесь на наши обновления</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
