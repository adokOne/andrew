<?php /*%%SmartyHeaderCode:1096568445421b3a27e4d39-71617101%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4563c0428bdf24f480992f66b15a2f588ef41f77' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcms/blockcms.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1096568445421b3a27e4d39-71617101',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421c11c90bcd9_87170213',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421c11c90bcd9_87170213')) {function content_5421c11c90bcd9_87170213($_smarty_tpl) {?>
	<!-- MODULE Block footer -->
	<section class="footer-block col-xs-12 col-sm-2" id="block_various_links_footer">
		<h4>Информация</h4>
		<ul class="toggle-footer">
							<li class="item">
					<a href="http://andrew.local/index.php?controller=prices-drop" title="Скидки">
						Скидки
					</a>
				</li>
									<li class="item">
				<a href="http://andrew.local/index.php?controller=new-products" title="Новые товары">
					Новые товары
				</a>
			</li>
										<li class="item">
					<a href="http://andrew.local/index.php?controller=best-sales" title="Популярные товары">
						Популярные товары
					</a>
				</li>
										<li class="item">
					<a href="http://andrew.local/index.php?controller=stores" title="Наши магазины">
						Наши магазины
					</a>
				</li>
									<li class="item">
				<a href="http://andrew.local/index.php?controller=contact" title="Свяжитесь с нами">
					Свяжитесь с нами
				</a>
			</li>
															<li class="item">
						<a href="http://andrew.local/index.php?id_cms=3&amp;controller=cms" title="Порядок и условия использования">
							Порядок и условия использования
						</a>
					</li>
																<li class="item">
						<a href="http://andrew.local/index.php?id_cms=4&amp;controller=cms" title="О компании">
							О компании
						</a>
					</li>
													<li>
				<a href="http://andrew.local/index.php?controller=sitemap" title="Карта сайта">
					Карта сайта
				</a>
			</li>
					</ul>
		
	</section>
		<section class="bottom-footer col-xs-12">
		<div>
			&copy; 2014 <a class="_blank" href="http://www.prestashop.com">Ecommerce software by PrestaShop™</a> &amp; designed by  <a href="http://www.devilthemes.com">devilthemes.com</a>
		</div>
	</section>
		<!-- /MODULE Block footer -->
<?php }} ?>
