<?php /*%%SmartyHeaderCode:1096568445421b3a27e4d39-71617101%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4563c0428bdf24f480992f66b15a2f588ef41f77' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcms/blockcms.tpl',
      1 => 1411593836,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1096568445421b3a27e4d39-71617101',
  'cache_lifetime' => 31536000,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5423368a969349_90070897',
  'has_nocache_code' => false,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5423368a969349_90070897')) {function content_5423368a969349_90070897($_smarty_tpl) {?>
	<!-- Block CMS module -->
			<section id="informations_block_left_1" class="block informations_block_left">
			<p class="title_block">
				<a href="http://andrew.local/index.php?id_cms_category=1&amp;controller=cms">
					Information				</a>
			</p>
			<div class="block_content list-block">
				<ul>
																							<li>
								<a href="http://andrew.local/index.php?id_cms=1&amp;controller=cms" title="Доставка">
									Доставка
								</a>
							</li>
																								<li>
								<a href="http://andrew.local/index.php?id_cms=2&amp;controller=cms" title="Правовое положение">
									Правовое положение
								</a>
							</li>
																								<li>
								<a href="http://andrew.local/index.php?id_cms=3&amp;controller=cms" title="Порядок и условия использования">
									Порядок и условия использования
								</a>
							</li>
																								<li>
								<a href="http://andrew.local/index.php?id_cms=4&amp;controller=cms" title="О компании">
									О компании
								</a>
							</li>
																								<li>
								<a href="http://andrew.local/index.php?id_cms=5&amp;controller=cms" title="Безопасность платежей">
									Безопасность платежей
								</a>
							</li>
																						<li>
							<a href="http://andrew.local/index.php?controller=stores" title="Наши магазины">
								Наши магазины
							</a>
						</li>
									</ul>
			</div>
		</section>
		<!-- /Block CMS module -->
<?php }} ?>
