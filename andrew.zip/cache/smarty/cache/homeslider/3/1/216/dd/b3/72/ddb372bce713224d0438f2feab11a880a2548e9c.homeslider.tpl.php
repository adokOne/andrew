<?php /*%%SmartyHeaderCode:20273240815421b3a31d15b6-00782758%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ddb372bce713224d0438f2feab11a880a2548e9c' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/homeslider/homeslider.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20273240815421b3a31d15b6-00782758',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421c11c960ec7_71424431',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421c11c960ec7_71424431')) {function content_5421c11c960ec7_71424431($_smarty_tpl) {?>    <!-- Module HomeSlider -->
            <div id="homepage-slider">
			            <ul id="homeslider" style="max-height:434px;">
                                                            <li class="homeslider-container">
                            <a href="http://www.prestashop.com/?utm_source=v16_homeslider" title="sample-1">
                                <img src="http://andrew.local/modules/homeslider/images/8934828e099f713c9d5a2ed699e9ab3fb910aff7_banner5.jpg" width="1000" height="434" alt="sample-1" />
                            </a>
                                                    </li>
                                                                                <li class="homeslider-container">
                            <a href="gergerg" title="ergergerg">
                                <img src="http://andrew.local/modules/homeslider/images/cf04531ec387520f94fb45d5faef2f82b9473673_samsung-ativ-s-neo-and-htc-8xt.jpg" width="630" height="350" alt="ergergerg" />
                            </a>
                                                            <div class="homeslider-description"><p>ergerger</p></div>
                                                    </li>
                                                </ul>
        </div>
        <!-- /Module HomeSlider -->
<?php }} ?>
