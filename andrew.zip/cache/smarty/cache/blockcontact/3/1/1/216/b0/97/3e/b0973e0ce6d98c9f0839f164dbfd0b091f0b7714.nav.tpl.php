<?php /*%%SmartyHeaderCode:9765189345421b3a2f1a134-76725736%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b0973e0ce6d98c9f0839f164dbfd0b091f0b7714' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcontact/nav.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9765189345421b3a2f1a134-76725736',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bc2075d939_51092215',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bc2075d939_51092215')) {function content_5421bc2075d939_51092215($_smarty_tpl) {?><div id="contact-link">
	<a href="http://andrew.local/index.php?controller=contact" title="Обратная связь">Обратная связь</a>
</div>
	<span class="shop-phone">
		<i class="icon-phone"></i>Звоните нам: <strong>0123-456-789</strong>
	</span>
</div><?php }} ?>
