<?php /*%%SmartyHeaderCode:9216127975421b3a09188e1-54692348%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b379290c1b4a079b69fe29d61e478d792f3a54c1' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blocktopmenu/blocktopmenu.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9216127975421b3a09188e1-54692348',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b78dc23a6_92042187',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b78dc23a6_92042187')) {function content_54233b78dc23a6_92042187($_smarty_tpl) {?>	<!-- Menu -->
	<div id="block_top_menu" class="sf-contener clearfix col-lg-12">
		<div class="cat-title">Категории</div>
		<ul class="sf-menu clearfix menu-content">
			<li><a href="http://andrew.local/index.php?id_category=3&amp;controller=category" title="Ноутбуки">Ноутбуки</a></li><li><a href="http://andrew.local/index.php?id_category=5&amp;controller=category" title="Телефоны">Телефоны</a></li>
					</ul>
	</div>
	<!--/ Menu -->
<?php }} ?>
