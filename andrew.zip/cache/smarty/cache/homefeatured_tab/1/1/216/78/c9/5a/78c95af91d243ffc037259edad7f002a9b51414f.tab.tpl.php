<?php /*%%SmartyHeaderCode:1167485945421b3a11239b1-14301914%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '78c95af91d243ffc037259edad7f002a9b51414f' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/homefeatured/tab.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1167485945421b3a11239b1-14301914',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b78ee4841_06469901',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b78ee4841_06469901')) {function content_54233b78ee4841_06469901($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#homefeatured" class="homefeatured">Популярное</a></li><?php }} ?>
