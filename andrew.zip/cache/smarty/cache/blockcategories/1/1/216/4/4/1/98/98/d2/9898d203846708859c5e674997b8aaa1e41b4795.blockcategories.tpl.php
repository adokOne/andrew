<?php /*%%SmartyHeaderCode:1636958655421b3a0b164b6-11053806%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9898d203846708859c5e674997b8aaa1e41b4795' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcategories/blockcategories.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1636958655421b3a0b164b6-11053806',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b90ba3ad1_59228462',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b90ba3ad1_59228462')) {function content_54233b90ba3ad1_59228462($_smarty_tpl) {?><?php }} ?>
