<?php /*%%SmartyHeaderCode:1636958655421b3a0b164b6-11053806%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9898d203846708859c5e674997b8aaa1e41b4795' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcategories/blockcategories.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
    'c2e73d985221ce790dec053c3425ca03548d9ef1' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcategories/category-tree-branch.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1636958655421b3a0b164b6-11053806',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b78e0e666_89819203',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b78e0e666_89819203')) {function content_54233b78e0e666_89819203($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Категории
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://andrew.local/index.php?id_category=3&amp;controller=category" title="">
		Ноутбуки
	</a>
	</li>

																
<li >
	<a 
	href="http://andrew.local/index.php?id_category=4&amp;controller=category" title="">
		Телевизоры
	</a>
	</li>

																
<li >
	<a 
	href="http://andrew.local/index.php?id_category=5&amp;controller=category" title="">
		Телефоны
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://andrew.local/index.php?id_category=6&amp;controller=category" title="">
		Фотоапараты
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
