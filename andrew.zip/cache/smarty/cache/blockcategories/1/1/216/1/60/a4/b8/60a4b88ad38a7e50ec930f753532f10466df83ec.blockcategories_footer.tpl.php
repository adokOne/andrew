<?php /*%%SmartyHeaderCode:13466275275421b3a2407086-58469981%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '60a4b88ad38a7e50ec930f753532f10466df83ec' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcategories/blockcategories_footer.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
    'c2e73d985221ce790dec053c3425ca03548d9ef1' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcategories/category-tree-branch.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13466275275421b3a2407086-58469981',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b790700f4_72342933',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b790700f4_72342933')) {function content_54233b790700f4_72342933($_smarty_tpl) {?>
<!-- Block categories module -->
<div class="col-xs-12 footer-block">
	<div class="row">
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Категории</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li >
	<a 
	href="http://andrew.local/index.php?id_category=3&amp;controller=category" title="">
		Ноутбуки
	</a>
	</li>

							
																
<li >
	<a 
	href="http://andrew.local/index.php?id_category=4&amp;controller=category" title="">
		Телевизоры
	</a>
	</li>

							
																
<li >
	<a 
	href="http://andrew.local/index.php?id_category=5&amp;controller=category" title="">
		Телефоны
	</a>
	</li>

							
																
<li class="last">
	<a 
	href="http://andrew.local/index.php?id_category=6&amp;controller=category" title="">
		Фотоапараты
	</a>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
