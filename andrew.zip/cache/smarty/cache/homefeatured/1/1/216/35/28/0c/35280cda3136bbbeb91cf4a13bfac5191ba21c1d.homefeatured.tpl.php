<?php /*%%SmartyHeaderCode:18903614115421b3a206cd74-53155295%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35280cda3136bbbeb91cf4a13bfac5191ba21c1d' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/homefeatured/homefeatured.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
    '44507dbabcbfb4a994edba284d4f7ac9c0dea07a' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/product-list.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18903614115421b3a206cd74-53155295',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b79044e91_01532574',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b79044e91_01532574')) {function content_54233b79044e91_01532574($_smarty_tpl) {?>
		
									
		
	
	<!-- Products list -->
	<ul id="homefeatured" class="product_list grid row homefeatured tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="http://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link"	href="http://andrew.local/index.php?id_product=1&amp;controller=product" title="Ноутбук HP ProBook 4740" itemprop="url">
							<img class="replace-2x img-responsive" src="http://andrew.local/img/p/1/1-home_default.jpg" alt="Ноутбук HP ProBook 4740" title="Ноутбук HP ProBook 4740"  width="250" height="250" itemprop="image" />
						</a>
													<a class="quick-view" href="http://andrew.local/index.php?id_product=1&amp;controller=product" rel="http://andrew.local/index.php?id_product=1&amp;controller=product">
								<span>Quick view</span>
							</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										10,00 ₴									</span>
									<meta itemprop="priceCurrency" content="0" />
																								</div>
																			<span class="new-box">
								<span class="new-label">New</span>
							</span>
																	</div>
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://andrew.local/index.php?id_product=1&amp;controller=product" title="Ноутбук HP ProBook 4740" itemprop="url" >
							Ноутбук HP ProBook 4740
						</a>
					</h5>
					 

					<p class="product-desc" itemprop="description">
						Экран 17.3'' (1600x900) HD+ LED, матовый / Intel Core i3-2370M (2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / AMD Radeon HD 7650M, 1 ГБ / DVD+/-RW / LAN / Wi-Fi / Bluetooth 4.0 / веб-камера / Linux / 3.05 кг + сумка
					</p>
										<div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
													<span itemprop="price" class="price product-price">
								10,00 ₴							</span>
							<meta itemprop="priceCurrency" content="0" />
																		</div>
										<div class="button-container">
																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://andrew.local/index.php?controller=cart&amp;add=1&amp;id_product=1&amp;token=41977cdff22882a198fb60bde267171e" rel="nofollow" title="Add to cart" data-id-product="1">
										<span>Add to cart</span>
									</a>
														
																			<a itemprop="url" class="button lnk_view btn btn-default" href="http://andrew.local/index.php?id_product=1&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
																	<span class="available-now">
										<link itemprop="availability" href="http://schema.org/InStock" />In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="http://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link"	href="http://andrew.local/index.php?id_product=2&amp;controller=product" title="Телевизор Samsung UE-32H5500" itemprop="url">
							<img class="replace-2x img-responsive" src="http://andrew.local/img/p/5/5-home_default.jpg" alt="Телевизор Samsung UE-32H5500" title="Телевизор Samsung UE-32H5500"  width="250" height="250" itemprop="image" />
						</a>
													<a class="quick-view" href="http://andrew.local/index.php?id_product=2&amp;controller=product" rel="http://andrew.local/index.php?id_product=2&amp;controller=product">
								<span>Quick view</span>
							</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										10,00 ₴									</span>
									<meta itemprop="priceCurrency" content="0" />
																								</div>
																			<span class="new-box">
								<span class="new-label">New</span>
							</span>
																			<span class="sale-box">
								<span class="sale-label">Sale!</span>
							</span>
											</div>
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://andrew.local/index.php?id_product=2&amp;controller=product" title="Телевизор Samsung UE-32H5500" itemprop="url" >
							Телевизор Samsung UE-32H5500
						</a>
					</h5>
					 

					<p class="product-desc" itemprop="description">
						Диагональ экрана: 32"
Разрешение: 1920x1080
Поддержка Smart TV: Есть
Диапазоны цифрового тюнера: DVB-C, DVB-T2
Частота развертки панели: 50 Гц
Частота обновления: 100 Гц (CMR)
Wi-Fi: Да
					</p>
										<div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
													<span itemprop="price" class="price product-price">
								10,00 ₴							</span>
							<meta itemprop="priceCurrency" content="0" />
																		</div>
										<div class="button-container">
																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://andrew.local/index.php?controller=cart&amp;add=1&amp;id_product=2&amp;token=41977cdff22882a198fb60bde267171e" rel="nofollow" title="Add to cart" data-id-product="2">
										<span>Add to cart</span>
									</a>
														
																			<a itemprop="url" class="button lnk_view btn btn-default" href="http://andrew.local/index.php?id_product=2&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																					</div>
																		<span itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
																	<span class="available-now">
										<link itemprop="availability" href="http://schema.org/InStock" />In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="http://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link"	href="http://andrew.local/index.php?id_product=3&amp;controller=product" title="Мобильный телефон Apple iPhone 5c 16GB " itemprop="url">
							<img class="replace-2x img-responsive" src="http://andrew.local/img/p/7/7-home_default.jpg" alt="Мобильный телефон Apple iPhone 5c 16GB " title="Мобильный телефон Apple iPhone 5c 16GB "  width="250" height="250" itemprop="image" />
						</a>
													<a class="quick-view" href="http://andrew.local/index.php?id_product=3&amp;controller=product" rel="http://andrew.local/index.php?id_product=3&amp;controller=product">
								<span>Quick view</span>
							</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										2,00 ₴									</span>
									<meta itemprop="priceCurrency" content="0" />
																								</div>
																			<span class="new-box">
								<span class="new-label">New</span>
							</span>
																	</div>
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://andrew.local/index.php?id_product=3&amp;controller=product" title="Мобильный телефон Apple iPhone 5c 16GB " itemprop="url" >
							Мобильный телефон Apple iPhone 5c 16GB
						</a>
					</h5>
					 

					<p class="product-desc" itemprop="description">
						Экран Retina 4" (1136x640), емкостный Multi-Touch / моноблок / двухъядерный Apple A6 (1.3 ГГц) / ОЗУ 1 ГБ / основная камера 8 Мп, фронтальная 1.2 Мп / Bluetooth 4.0 / Wi-Fi 802.11a/b/g/n / A-GPS / GLONASS / 16 ГБ встроенной памяти / разъем 3.5 мм / LTE / iOS 7 / 124.4 x 59.2 x 8.97 мм, 132 г / зеленый
					</p>
										<div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
													<span itemprop="price" class="price product-price">
								2,00 ₴							</span>
							<meta itemprop="priceCurrency" content="0" />
																		</div>
										<div class="button-container">
																					<span class="button ajax_add_to_cart_button btn btn-default disabled">
									<span>Add to cart</span>
								</span>
																			<a itemprop="url" class="button lnk_view btn btn-default" href="http://andrew.local/index.php?id_product=3&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
																	<span class="out-of-stock">
										<link itemprop="availability" href="http://schema.org/OutOfStock" />Out of stock
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line last-line first-item-of-tablet-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="http://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link"	href="http://andrew.local/index.php?id_product=4&amp;controller=product" title="Фотоаппарат Canon EOS 700D 18-55mm STM" itemprop="url">
							<img class="replace-2x img-responsive" src="http://andrew.local/img/p/8/8-home_default.jpg" alt="Фотоаппарат Canon EOS 700D 18-55mm STM" title="Фотоаппарат Canon EOS 700D 18-55mm STM"  width="250" height="250" itemprop="image" />
						</a>
													<a class="quick-view" href="http://andrew.local/index.php?id_product=4&amp;controller=product" rel="http://andrew.local/index.php?id_product=4&amp;controller=product">
								<span>Quick view</span>
							</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										10,00 ₴									</span>
									<meta itemprop="priceCurrency" content="0" />
																								</div>
																			<span class="new-box">
								<span class="new-label">New</span>
							</span>
																	</div>
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://andrew.local/index.php?id_product=4&amp;controller=product" title="Фотоаппарат Canon EOS 700D 18-55mm STM" itemprop="url" >
							Фотоаппарат Canon EOS 700D 18-55mm STM
						</a>
					</h5>
					 

					<p class="product-desc" itemprop="description">
						Матрица 22.3 x 14.9 мм, 18 Мп / объектив 18-55 IS STM / поддержка карт памяти SD/SDHC/SDXC / Сенсорный ЖК-экран с переменным углом наклона Clear View II TFT 3" / FullHD-видео / питание от литий-ионного аккумулятора / 133.1 x 99.8 x 154.0 мм, 785 г
					</p>
										<div itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="content_price">
													<span itemprop="price" class="price product-price">
								10,00 ₴							</span>
							<meta itemprop="priceCurrency" content="0" />
																		</div>
										<div class="button-container">
																					<span class="button ajax_add_to_cart_button btn btn-default disabled">
									<span>Add to cart</span>
								</span>
																			<a itemprop="url" class="button lnk_view btn btn-default" href="http://andrew.local/index.php?id_product=4&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span itemprop="offers" itemscope itemtype="http://schema.org/Offer" class="availability">
																	<span class="out-of-stock">
										<link itemprop="availability" href="http://schema.org/OutOfStock" />Out of stock
									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
