<?php /*%%SmartyHeaderCode:10894135035421b3c5a0d322-83265195%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18cbac3ba4de3be25dd6534a593285fcbdaa4658' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blocknewproducts/blocknewproducts.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10894135035421b3c5a0d322-83265195',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b90c156b8_08927335',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b90c156b8_08927335')) {function content_54233b90c156b8_08927335($_smarty_tpl) {?><!-- MODULE Block new products -->
<div id="new-products_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://andrew.local/index.php?controller=new-products" title="Новые товары">Новые товары</a>
    </h4>
    <div class="block_content products-block">
                    <ul class="products">
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://andrew.local/index.php?id_product=4&amp;controller=product" title="Фотоаппарат Canon EOS 700D 18-55mm STM"><img class="replace-2x img-responsive" src="http://andrew.local/img/p/8/8-small_default.jpg" alt="Фотоаппарат Canon EOS 700D 18-55mm STM" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://andrew.local/index.php?id_product=4&amp;controller=product" title="Фотоаппарат Canon EOS 700D 18-55mm STM">Фотоаппарат Canon EOS 700D 18-55mm STM</a>
                            </h5>
                        	<p class="product-description">Матрица 22.3 x 14.9 мм, 18 Мп / объектив 18-55 IS STM / поддержка карт...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	10,00 ₴                                        </span>
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://andrew.local/index.php?id_product=3&amp;controller=product" title="Мобильный телефон Apple iPhone 5c 16GB "><img class="replace-2x img-responsive" src="http://andrew.local/img/p/7/7-small_default.jpg" alt="Мобильный телефон Apple iPhone 5c 16GB " /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://andrew.local/index.php?id_product=3&amp;controller=product" title="Мобильный телефон Apple iPhone 5c 16GB ">Мобильный телефон Apple iPhone 5c 16GB </a>
                            </h5>
                        	<p class="product-description">Экран Retina 4" (1136x640), емкостный Multi-Touch / моноблок /...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	2,00 ₴                                        </span>
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://andrew.local/index.php?id_product=2&amp;controller=product" title="Телевизор Samsung UE-32H5500"><img class="replace-2x img-responsive" src="http://andrew.local/img/p/5/5-small_default.jpg" alt="Телевизор Samsung UE-32H5500" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://andrew.local/index.php?id_product=2&amp;controller=product" title="Телевизор Samsung UE-32H5500">Телевизор Samsung UE-32H5500</a>
                            </h5>
                        	<p class="product-description">Диагональ экрана: 32"
Разрешение: 1920x1080
Поддержка Smart TV: Есть...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	10,00 ₴                                        </span>
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://andrew.local/index.php?id_product=1&amp;controller=product" title="Ноутбук HP ProBook 4740"><img class="replace-2x img-responsive" src="http://andrew.local/img/p/1/1-small_default.jpg" alt="Ноутбук HP ProBook 4740" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://andrew.local/index.php?id_product=1&amp;controller=product" title="Ноутбук HP ProBook 4740">Ноутбук HP ProBook 4740</a>
                            </h5>
                        	<p class="product-description">Экран 17.3'' (1600x900) HD+ LED, матовый / Intel Core i3-2370M (2.4 ГГц)...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	10,00 ₴                                        </span>
                                    </div>
                                                                                    </div>
                    </li>
                            </ul>
            <div>
                <a href="http://andrew.local/index.php?controller=new-products" title="Все новые товары" class="btn btn-default button button-small"><span>Все новые товары<i class="icon-chevron-right right"></i></span></a>
            </div>
            </div>
</div>
<!-- /MODULE Block new products --><?php }} ?>
