<?php /*%%SmartyHeaderCode:1293856130541c0620b73dd9-52648747%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e930e3c47a78c9a2022a765362619488b295436c' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/blockcmsinfo/blockcmsinfo.tpl',
      1 => 1406806896,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1293856130541c0620b73dd9-52648747',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_542334fe6274f4_07591221',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_542334fe6274f4_07591221')) {function content_542334fe6274f4_07591221($_smarty_tpl) {?><!-- MODULE Block cmsinfo -->
<div id="cmsinfo_block">
					<div class="col-xs-6"><ul>
<li><em class="icon-truck" id="icon-truck"></em>
<div class="type-text">
<h3>Lorem Ipsum</h3>
<p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p>
</div>
</li>
<li><em class="icon-phone" id="icon-phone"></em>
<div class="type-text">
<h3>Dolor Sit Amet</h3>
<p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p>
</div>
</li>
<li><em class="icon-credit-card" id="icon-credit-card"></em>
<div class="type-text">
<h3>Ctetur Voluptate</h3>
<p>Lorem ipsum dolor sit amet conse ctetur voluptate velit esse cillum dolore eu</p>
</div>
</li>
</ul></div>
					<div class="col-xs-6"><h3>Custom Block</h3>
<p><strong class="dark">Lorem ipsum dolor sit amet conse ctetu</strong></p>
<p>Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.</p></div>
		</div>
<!-- /MODULE Block cmsinfo -->
<?php }} ?>
