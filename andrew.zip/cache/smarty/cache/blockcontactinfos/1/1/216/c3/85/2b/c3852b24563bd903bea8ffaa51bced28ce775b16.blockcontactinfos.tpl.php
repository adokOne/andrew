<?php /*%%SmartyHeaderCode:1880386815421b3a2a57fa3-47715627%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3852b24563bd903bea8ffaa51bced28ce775b16' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockcontactinfos/blockcontactinfos.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1880386815421b3a2a57fa3-47715627',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_542334feb72bb4_65221617',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_542334feb72bb4_65221617')) {function content_542334feb72bb4_65221617($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <h4>Контактная информация</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>My Company, 42 avenue des Champs Elysées
75000 Paris
France            	</li>
                                    	<li>
            		<i class="icon-phone"></i>Телефоны: 
            		<span>0123-456-789</span>
            	</li>
                                    	<li>
            		<i class="icon-envelope-alt"></i>E-mail: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%61%6c%65%73@%79%6f%75%72%63%6f%6d%70%61%6e%79.%63%6f%6d" >&#x73;&#x61;&#x6c;&#x65;&#x73;&#x40;&#x79;&#x6f;&#x75;&#x72;&#x63;&#x6f;&#x6d;&#x70;&#x61;&#x6e;&#x79;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
    </div>
</section>
</div></div>
<!-- /MODULE Block contact infos -->
<?php }} ?>
