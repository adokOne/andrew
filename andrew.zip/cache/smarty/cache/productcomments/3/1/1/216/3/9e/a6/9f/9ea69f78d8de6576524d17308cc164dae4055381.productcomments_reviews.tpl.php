<?php /*%%SmartyHeaderCode:17350602095421b3a1c112b4-39722287%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ea69f78d8de6576524d17308cc164dae4055381' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/productcomments/productcomments_reviews.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17350602095421b3a1c112b4-39722287',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bdd71947d9_62570100',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bdd71947d9_62570100')) {function content_5421bdd71947d9_62570100($_smarty_tpl) {?> 
<?php }} ?>
