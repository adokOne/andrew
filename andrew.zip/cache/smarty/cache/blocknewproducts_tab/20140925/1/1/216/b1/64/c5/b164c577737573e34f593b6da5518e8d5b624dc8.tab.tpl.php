<?php /*%%SmartyHeaderCode:8578228625421b3a0f0f7d4-70900104%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b164c577737573e34f593b6da5518e8d5b624dc8' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blocknewproducts/tab.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8578228625421b3a0f0f7d4-70900104',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233b78ec9233_53761155',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233b78ec9233_53761155')) {function content_54233b78ec9233_53761155($_smarty_tpl) {?>
<li class="active"><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">Новые поступления</a></li><?php }} ?>
