<?php /*%%SmartyHeaderCode:1583836975421bbd8540758-61638663%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2511c9adc67bb80a303f3c779ce8569604bc81c8' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/productpaymentlogos/views/templates/hook/productpaymentlogos.tpl',
      1 => 1406806952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1583836975421bbd8540758-61638663',
  'variables' => 
  array (
    'content_only' => 0,
    'banner_title' => 0,
    'banner_link' => 0,
    'module_dir' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bbd85ac458_98424525',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bbd85ac458_98424525')) {function content_5421bbd85ac458_98424525($_smarty_tpl) {?><!-- Productpaymentlogos module -->
<div id="product_payment_logos">
	<div class="box-security">
    <h5 class="product-heading-h5"></h5> 
  			<img src="/modules/productpaymentlogos/img/payment-logo.png" alt="" class="img-responsive" />
	    </div>
</div>
  
<!-- /Productpaymentlogos module -->
<?php }} ?>
