<?php /*%%SmartyHeaderCode:1583836975421bbd8540758-61638663%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2511c9adc67bb80a303f3c779ce8569604bc81c8' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/productpaymentlogos/views/templates/hook/productpaymentlogos.tpl',
      1 => 1406806952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1583836975421bbd8540758-61638663',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5423389db31615_52169393',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5423389db31615_52169393')) {function content_5423389db31615_52169393($_smarty_tpl) {?><!-- Productpaymentlogos module -->
  
<!-- /Productpaymentlogos module -->
<?php }} ?>
