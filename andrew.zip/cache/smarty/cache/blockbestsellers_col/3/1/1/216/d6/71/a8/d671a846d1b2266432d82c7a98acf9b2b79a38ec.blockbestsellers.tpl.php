<?php /*%%SmartyHeaderCode:1653573365421bdb857c208-56134586%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd671a846d1b2266432d82c7a98acf9b2b79a38ec' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockbestsellers/blockbestsellers.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1653573365421bdb857c208-56134586',
  'variables' => 
  array (
    'link' => 0,
    'best_sellers' => 0,
    'product' => 0,
    'PS_CATALOG_MODE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bdb8629c91_58495448',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bdb8629c91_58495448')) {function content_5421bdb8629c91_58495448($_smarty_tpl) {?>
<!-- MODULE Block best sellers -->
<div id="best-sellers_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://andrew.local/index.php?controller=best-sales" title="Просмотреть самые продаваемые товары">Популярные товары</a>
    </h4>
	<div class="block_content">
			<ul class="block_content products-block">
						<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/7/7-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=2&amp;controller=product&amp;id_lang=1" title="">
                            Blouse
                        </a>
                    </h5>
                    <p class="product-description">Short sleeved blouse with feminine draped sleeve detail.</p>
                                            <div class="price-box">
                            <span class="price">32,40 ₴</span>
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/1/1-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=1&amp;controller=product&amp;id_lang=1" title="">
                            Faded Short Sleeve T-shirts
                        </a>
                    </h5>
                    <p class="product-description">Faded short sleeve t-shirt with high neckline. Soft and stretchy...</p>
                                            <div class="price-box">
                            <span class="price">19,81 ₴</span>
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/8/8-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=3&amp;controller=product&amp;id_lang=1" title="">
                            Printed Dress
                        </a>
                    </h5>
                    <p class="product-description">100% cotton double printed dress. Black and white striped top and orange...</p>
                                            <div class="price-box">
                            <span class="price">31,20 ₴</span>
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/1/6/16-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=6&amp;controller=product&amp;id_lang=1" title="">
                            Printed Summer Dress
                        </a>
                    </h5>
                    <p class="product-description">Sleeveless knee-length chiffon dress. V-neckline with elastic under the...</p>
                                            <div class="price-box">
                            <span class="price">36,60 ₴</span>
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/2/0/20-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=7&amp;controller=product&amp;id_lang=1" title="">
                            Printed Chiffon Dress
                        </a>
                    </h5>
                    <p class="product-description">Printed chiffon knee length dress with tank straps. Deep v-neckline.</p>
                                            <div class="price-box">
                            <span class="price">19,68 ₴</span>
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://andrew.local/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://andrew.local/img/p/1/2/12-small_default.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://andrew.local/index.php?id_product=5&amp;controller=product&amp;id_lang=1" title="">
                            Printed Summer Dress
                        </a>
                    </h5>
                    <p class="product-description">Long printed dress with thin adjustable straps. V-neckline and wiring...</p>
                                            <div class="price-box">
                            <span class="price">34,78 ₴</span>
                        </div>
                                    </div>
			</li>
				</ul>
		<div class="lnk">
        	<a href="http://andrew.local/index.php?controller=best-sales" title="Все популярные товары"  class="btn btn-default button button-small"><span>Все популярные товары<i class="icon-chevron-right right"></i></span></a>
        </div>
		</div>
</div>
<!-- /MODULE Block best sellers --><?php }} ?>
