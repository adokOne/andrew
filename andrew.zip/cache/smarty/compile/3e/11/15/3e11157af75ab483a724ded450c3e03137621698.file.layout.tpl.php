<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 13:34:32
         compiled from "/home/adok/WWW/andrew/odmin/themes/default/template/controllers/login/layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1627271691541c06b82b8654-11225341%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3e11157af75ab483a724ded450c3e03137621698' => 
    array (
      0 => '/home/adok/WWW/andrew/odmin/themes/default/template/controllers/login/layout.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1627271691541c06b82b8654-11225341',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c06b82c0c43_55157336',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c06b82c0c43_55157336')) {function content_541c06b82c0c43_55157336($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
