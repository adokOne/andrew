<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:57
         compiled from "/home/adok/WWW/andrew/admin/themes/default/template/controllers/shop_url/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1268969481541c043da0f9c5-56979990%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52ef07efc414246f091e56d823b060ec44c8330c' => 
    array (
      0 => '/home/adok/WWW/andrew/admin/themes/default/template/controllers/shop_url/content.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1268969481541c043da0f9c5-56979990',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c043da13d14_57830846',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c043da13d14_57830846')) {function content_541c043da13d14_57830846($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("controllers/shop/content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
