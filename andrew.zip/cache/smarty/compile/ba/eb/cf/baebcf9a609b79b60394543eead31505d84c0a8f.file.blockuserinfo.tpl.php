<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:53
         compiled from "/home/adok/WWW/andrew/themes/default-bootstrap/modules/blockuserinfo/blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1455776567541c0439a7d206-27027140%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'baebcf9a609b79b60394543eead31505d84c0a8f' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/default-bootstrap/modules/blockuserinfo/blockuserinfo.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1455776567541c0439a7d206-27027140',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c0439a7dab5_09315521',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c0439a7dab5_09315521')) {function content_541c0439a7dab5_09315521($_smarty_tpl) {?><?php }} ?>
