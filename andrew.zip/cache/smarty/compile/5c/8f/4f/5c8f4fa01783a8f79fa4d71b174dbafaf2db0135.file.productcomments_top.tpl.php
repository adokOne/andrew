<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:54
         compiled from "/home/adok/WWW/andrew/themes/default-bootstrap/modules/productcomments/productcomments_top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:997699440541c043a91d207-50614351%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5c8f4fa01783a8f79fa4d71b174dbafaf2db0135' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/default-bootstrap/modules/productcomments/productcomments_top.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '997699440541c043a91d207-50614351',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c043a91d5e4_22120143',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c043a91d5e4_22120143')) {function content_541c043a91d5e4_22120143($_smarty_tpl) {?><?php }} ?>
