<?php /* Smarty version Smarty-3.1.19, created on 2014-09-23 21:28:40
         compiled from "/home/adok/WWW/andrew/themes/blackhawk3.0/modules/productcomments//tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10949766865421bbd87f1157-58046636%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5b3d289140e2acfc4bfbb4cb530bceda6a3f9347' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/productcomments//tab.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10949766865421bbd87f1157-58046636',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421bbd88104c3_15774829',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421bbd88104c3_15774829')) {function content_5421bbd88104c3_15774829($_smarty_tpl) {?>

<h3 id="#idTab5" class="idTabHrefShort page-product-heading"><?php echo smartyTranslate(array('s'=>'Reviews','mod'=>'productcomments'),$_smarty_tpl);?>
</h3> <?php }} ?>
