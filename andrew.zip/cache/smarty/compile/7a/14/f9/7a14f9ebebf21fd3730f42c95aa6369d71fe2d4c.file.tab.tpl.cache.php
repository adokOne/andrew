<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 13:32:00
         compiled from "/home/adok/WWW/andrew/themes/default-bootstrap/modules/blockbestsellers/tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:534305892541c0620dd4962-68240337%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7a14f9ebebf21fd3730f42c95aa6369d71fe2d4c' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/default-bootstrap/modules/blockbestsellers/tab.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '534305892541c0620dd4962-68240337',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c0620de0b80_12429234',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c0620de0b80_12429234')) {function content_541c0620de0b80_12429234($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers"><?php echo smartyTranslate(array('s'=>'Best Sellers','mod'=>'blockbestsellers'),$_smarty_tpl);?>
</a></li><?php }} ?>
