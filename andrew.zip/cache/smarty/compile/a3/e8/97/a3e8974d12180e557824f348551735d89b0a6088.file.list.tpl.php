<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 13:35:06
         compiled from "/home/adok/WWW/andrew/odmin/themes/default/template/helpers/list/list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1209963652541c06da0fc737-32289751%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a3e8974d12180e557824f348551735d89b0a6088' => 
    array (
      0 => '/home/adok/WWW/andrew/odmin/themes/default/template/helpers/list/list.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1209963652541c06da0fc737-32289751',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c06da105062_65976354',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c06da105062_65976354')) {function content_541c06da105062_65976354($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>
