<?php /* Smarty version Smarty-3.1.19, created on 2014-09-25 00:40:04
         compiled from "/home/adok/WWW/andrew/modules/blockcategories/views/blockcategories_admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:121007912254233a3463cc22-91739896%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '04a82d202a67d9ced2466536d8a9daa5b59165f6' => 
    array (
      0 => '/home/adok/WWW/andrew/modules/blockcategories/views/blockcategories_admin.tpl',
      1 => 1406806894,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '121007912254233a3463cc22-91739896',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'helper' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_54233a34645632_36351355',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54233a34645632_36351355')) {function content_54233a34645632_36351355($_smarty_tpl) {?><div class="form-group">
	<label class="control-label col-lg-3">
		<span class="label-tooltip" data-toggle="tooltip" data-html="true" title="" data-original-title="<?php echo smartyTranslate(array('s'=>'You can upload a maximum of 3 images.','mod'=>'blockcategories'),$_smarty_tpl);?>
">
			<?php echo smartyTranslate(array('s'=>'Thumbnails','mod'=>'blockcategories'),$_smarty_tpl);?>

		</span>
	</label>
	<div class="col-lg-4">
		<?php echo $_smarty_tpl->tpl_vars['helper']->value;?>

	</div>
</div><?php }} ?>
