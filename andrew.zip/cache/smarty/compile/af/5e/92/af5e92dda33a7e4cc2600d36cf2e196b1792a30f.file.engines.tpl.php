<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:53
         compiled from "/home/adok/WWW/andrew/admin/themes/default/template/controllers/stats/engines.tpl" */ ?>
<?php /*%%SmartyHeaderCode:226707329541c043981e528-06467774%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'af5e92dda33a7e4cc2600d36cf2e196b1792a30f' => 
    array (
      0 => '/home/adok/WWW/andrew/admin/themes/default/template/controllers/stats/engines.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '226707329541c043981e528-06467774',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c0439820357_15004959',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c0439820357_15004959')) {function content_541c0439820357_15004959($_smarty_tpl) {?>

<?php }} ?>
