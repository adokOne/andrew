<?php /* Smarty version Smarty-3.1.19, created on 2014-09-25 00:30:26
         compiled from "/home/adok/WWW/andrew/odmin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:889693010542337f26bdad6-74793727%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '865071a4b1affa8c0f19b695f6d6e11b065866d9' => 
    array (
      0 => '/home/adok/WWW/andrew/odmin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '889693010542337f26bdad6-74793727',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_542337f26c7486_97730620',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_542337f26c7486_97730620')) {function content_542337f26c7486_97730620($_smarty_tpl) {?>

<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
