<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:56
         compiled from "/home/adok/WWW/andrew/themes/default-bootstrap/modules/blocklayered/blocklayered-no-products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1028786586541c043c5966b6-35802223%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '41ee83c2f1dcb18b5e2a11b6898947c83d03ffdb' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/default-bootstrap/modules/blocklayered/blocklayered-no-products.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1028786586541c043c5966b6-35802223',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c043c59baa3_02034717',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c043c59baa3_02034717')) {function content_541c043c59baa3_02034717($_smarty_tpl) {?>
<div class="product_list">
	<p class="alert alert-warning"><?php echo smartyTranslate(array('s'=>'There are no products.','mod'=>'blocklayered'),$_smarty_tpl);?>
</p>
</div>
<?php }} ?>
