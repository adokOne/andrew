<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 13:32:00
         compiled from "/home/adok/WWW/andrew/themes/default-bootstrap/modules/blocknewproducts/tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2060096231541c0620d58cc0-97085149%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '16da7f1654e994c0d1ec6678586136773f4e7eff' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/default-bootstrap/modules/blocknewproducts/tab.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2060096231541c0620d58cc0-97085149',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c0620d65798_35294560',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c0620d65798_35294560')) {function content_541c0620d65798_35294560($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts"><?php echo smartyTranslate(array('s'=>'New arrivals','mod'=>'blocknewproducts'),$_smarty_tpl);?>
</a></li><?php }} ?>
