<?php /* Smarty version Smarty-3.1.19, created on 2014-09-19 10:23:56
         compiled from "/home/adok/WWW/andrew/admin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:596865132541c043c7fb556-31885694%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '707a040ebdc41dcbd34119a704cf7cfd1d6001a2' => 
    array (
      0 => '/home/adok/WWW/andrew/admin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl',
      1 => 1406806856,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '596865132541c043c7fb556-31885694',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_541c043c808557_17383612',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_541c043c808557_17383612')) {function content_541c043c808557_17383612($_smarty_tpl) {?>

<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
