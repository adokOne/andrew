<?php /* Smarty version Smarty-3.1.19, created on 2014-09-23 20:53:36
         compiled from "/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockuserinfo/blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9072237515421b3a0092b37-08147096%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b093cdafc2f2431f7473b11ccff7b27d2f39fdd' => 
    array (
      0 => '/home/adok/WWW/andrew/themes/blackhawk3.0/modules/blockuserinfo/blockuserinfo.tpl',
      1 => 1411494587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9072237515421b3a0092b37-08147096',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5421b3a0093720_96291123',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5421b3a0093720_96291123')) {function content_5421b3a0093720_96291123($_smarty_tpl) {?><?php }} ?>
